These are the default controls, but you can change them on the settings menu.
Keyboard:
up arrow = accelerate
left and right arrows = steering
left shift = brakes
x = slide
1 = respawn
esc and enter = pause

Controller:
right trigger = accelerate
left trigger = brakes
thumbstick = steer
B or Circle = ebrake
start = pause
select = respawn

Make sure to go to settings and mess with the settings to find something that is comfortable.
Have fun, break the game, and tell me as many of your thoughts as possible.
